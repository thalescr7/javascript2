var num1=792;
var num2=8372;

///console.log (num1+num2);

var soma
var resultado;

function calcularsoma(num1,num2) {
  soma = num1 + num2
  return soma;
}

resultado = calcularsoma(num1 , num2);
console.log('A soma é:',num1,'e',num2,'é' ,resultado)

num1=727
num2=72

resultado = calcularsoma(num1,num2);
console.log('A soma é:',num1,'e',num2,'é' ,resultado)
